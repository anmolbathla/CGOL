/*
 * @author: Anmol Bathla
 * @version: 1.0
 * Description: This code specifies the code of Conway's Game of Life
 */
#include <stdio.h>
#include <stdlib.h>

int main(){
   int firstgen[5][5];

   int i, j;
   for(i=0; i<5; i++) {
      for(j=0;j<5;j++) {
         printf("Enter the values of firstgen[%d][%d]:", i, j);
         fflush(stdout);
         scanf("%d", &firstgen[i][j]);
      }

   }

   //Display elements of nextgen
   printf("First Generation:\n");
   for(i=0; i<5; i++) {
      for(j=0;j<5;j++) {

         printf("%d", firstgen[i][j]);
      }

      printf("\n");
   }


  void fun(int n, int m, int firstgen[n][m]);
  const int n=5,m=5;

  fun(n,m,firstgen);

  return 0;
}

void fun(int n,int m, int firstgen[n][m]){

int nextgen[5][5];
int i,j;
int an = 0;
for(i=0; i<5; i++){
for(j=0;j<5;j++){
an = 0;
int l,k;
               for (l = -1; l <= 1; l++){
                   for (k = -1; k <= 1; k++){

                    if (firstgen[i+l][j+k]==1){
                    an++;

                    }
                   }

}
               an = an - firstgen[i][j];
               if (an < 2)
                                   nextgen[i][j] = 0;
                               // Cell dies due to over population
                               else if (an > 3)
                                   nextgen[i][j] = 0;

                               // A new cell is born
                               else if (an == 3)
                                   nextgen[i][j] = 1;

                               // Remains the same
                               else if (an==2){

                                if(firstgen[i][j]==1){
                                nextgen[i][j]=1;
                                }
                                else
                                nextgen[i][j]=0;

                               }

}
}

int a,b;
printf("\n");
printf("Second Generation:\n");
for(a=0; a<5; a++) {
     for(b=0;b<5;b++) {

        printf("%d", nextgen[a][b]);
     }
     printf("\n");
  }
}
