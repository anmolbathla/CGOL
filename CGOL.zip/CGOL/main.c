#include <stdio.h>

void main() {
    int i, j;
    int array[3][3];
    int array1[3][3];
    int an=0;
    printf("Enter elements of Array: ");
    for (i=0; i<3; i++)
    {
        for(j=0; j<3; j++)
        {
            scanf("%d ", &array[i][j]);
        }
    }


    for (int i=0; i<3; i++)
    {
        for(int j=0; j<3; j++)
        {
            for(int n=-1; n<=1; n++)
            {
                for(int m=-1; m<=1; m++)
                {
                    if (array[i+n][j+m] == 1)
                    {
                        an++;
                    }
                }
            }
            an = an - array[i][j];

            if (an < 2) {
                array1[i][j] = 0;
            }
            else if (an >3)
            {
                array1[i][j] = 0;
            }
            else if (an == 2 && array[i][j] == 0)
            {
                array1[i][j] = 0;
            }
            else if (array[i][j] == 1)
            {
                if (an ==2 || an == 3)
                {
                    array1[i][j] = 1;
                }
            }
            else
            {
                array1[i][j] = 0;
            }
        }
    }
    printf("The answer: ");
    for (int i = 0; i<3; i++)
    {
        for (int j=0; j<3; j++)
        {
            printf("%d \n", &array1[i][j]);
        }
    }
}
